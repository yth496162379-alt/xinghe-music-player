package com.xinghe.musicplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private lateinit var playButton: Button

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            playUri(uri, "正在播放本地音乐")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playButton.text = if (isPlaying) "暂停" else "继续播放"
            }
            override fun onPlayerError(error: PlaybackException) {
                status.text = "播放失败：链接可能不是可直接播放的音频，或需要平台授权。"
            }
        })
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 40, 24, 24)
            setBackgroundColor(0xFFF6F3FC.toInt())
        }
        page.addView(TextView(this).apply {
            text = "✦ 星河音乐"
            textSize = 30f
            setTextColor(0xFF29223D.toInt())
            gravity = Gravity.CENTER
        }, match(WRAP, 72))
        page.addView(TextView(this).apply {
            text = "你的私人音乐空间"
            textSize = 15f
            setTextColor(0xFF716A7D.toInt())
            gravity = Gravity.CENTER
        }, match(WRAP, 42))

        val import = Button(this).apply {
            text = "导入手机本地音乐"
            setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }
        }
        page.addView(import, match(MATCH, 56))

        page.addView(TextView(this).apply {
            text = "播放网络音频"
            textSize = 18f
            setTextColor(0xFF29223D.toInt())
            setPadding(0, 28, 0, 8)
        }, match(WRAP, WRAP))

        urlInput = EditText(this).apply {
            hint = "粘贴 MP3 / WAV / 可直连音频地址"
            textSize = 14f
            singleLine = true
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(urlInput, match(MATCH, 54))

        page.addView(Button(this).apply {
            text = "播放链接"
            setOnClickListener {
                val raw = urlInput.text.toString().trim()
                if (raw.isBlank() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
                    Toast.makeText(this@MainActivity, "请先粘贴有效的 http/https 链接", Toast.LENGTH_SHORT).show()
                } else {
                    playUri(Uri.parse(raw), "正在尝试播放网络音频")
                }
            }
        }, match(MATCH, 54))

        playButton = Button(this).apply {
            text = "暂停"
            setOnClickListener {
                val p = player ?: return@setOnClickListener
                if (p.isPlaying) p.pause() else p.play()
            }
        }
        page.addView(playButton, match(MATCH, 54))

        status = TextView(this).apply {
            text = "请选择本地歌曲，或粘贴可直接访问的音频文件链接。"
            textSize = 14f
            setTextColor(0xFF625B70.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 8)
        }
        page.addView(status, match(MATCH, WRAP))

        page.addView(TextView(this).apply {
            text = "支持本地音频及公开直链。网易云、QQ 音乐、Suno 等网页分享链接不一定是音频直链；若平台有登录、版权或 DRM 限制，本播放器不会绕过这些限制。"
            textSize = 12f
            setTextColor(0xFF817A8D.toInt())
            setPadding(8, 28, 8, 8)
        }, match(MATCH, WRAP))

        setContentView(page)
    }

    private fun playUri(uri: Uri, message: String) {
        try {
            val p = player ?: return
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            p.play()
            status.text = message
        } catch (e: Exception) {
            status.text = "无法打开该音频：${e.localizedMessage ?: "未知错误"}"
        }
    }

    private fun match(width: Int, height: Int) =
        LinearLayout.LayoutParams(width, height).apply { bottomMargin = 10 }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
