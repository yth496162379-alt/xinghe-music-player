# 星河音乐播放器

Android 原生项目，提供本地音频选择、公开 HTTP(S) 音频直链播放和基础播放控制。

## 构建 APK
仓库推送到 `main` 后，GitHub Actions 会自动构建 Debug APK。也可以在 Actions 页面手动运行 `Build Android APK`。构建成功后，在对应运行记录的 Artifacts 下载 `Xinghe-Music-debug-apk`。

## 支持范围
- 手机本地音频（通过系统文件选择器导入）
- 可公开访问的 MP3、WAV 等音频直链
- 普通 HTTP(S) 音频流（取决于服务器是否允许访问）

网易云音乐、QQ 音乐、Suno 等分享页面链接通常不是音频文件直链，可能需要官方登录、授权或受 DRM/版权保护。本项目不会绕过平台访问控制。
